#!/bin/bash
echo "A: var1 in bash.sh: $var1"

var1=456
echo "B: var1 in 001.sh: $var1"
