#STDIN
echo -n "Type something and press ENTER"

read entry

echo "you type: $entry"
