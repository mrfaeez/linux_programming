echo -n "What fruits do you like"

read fr1 fr2

echo "You like 1:$fr1, 2:$fr2"
