##!/bin/bash
#shabang : absolute path to the script's intepreter

echo "SCRIPT TO PRACTICE BASH PROGRAMMING"

var1=123
var2="Anthony says \"HELLO WORLD\""

echo '$var1 \"OK\"'
echo "$var2, $var1"

export var1
#export to global
